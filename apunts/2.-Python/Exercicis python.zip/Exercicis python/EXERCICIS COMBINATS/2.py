compra = []

producte = input("Introdueix un producte (fi per acabar): ")

while producte != "fi":
    compra.append(producte)
    producte = input("Introdueix un producte (fi per acabar): ")

print("\nNombre de productes:", len(compra))

print("Llista de productes:")
for p in compra:
    print(p)

buscar = input("\nQuin producte vols buscar? ")

trobat = False
for p in compra:
    if p == buscar:
        trobat = True

if trobat == True:
    print("El producte està en la llista.")
else:
    print("El producte no està en la llista.")
