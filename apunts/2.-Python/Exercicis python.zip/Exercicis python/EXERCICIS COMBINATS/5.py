assignatures = ("Matemàtiques", "Valencià", "Anglés", "Història", "Biologia")
notes = {}

for a in assignatures:
    nota = float(input("Nota de " + a + ": "))
    notes[a] = nota

millor = ""
millor_nota = 0
suspeses = 0

for a in notes:
    if notes[a] > millor_nota:
        millor_nota = notes[a]
        millor = a
    if notes[a] < 5:
        suspeses = suspeses + 1

print("\nAssignatura amb millor nota:", millor)
print("Millor nota:", millor_nota)
print("Assignatures suspeses:", suspeses)
