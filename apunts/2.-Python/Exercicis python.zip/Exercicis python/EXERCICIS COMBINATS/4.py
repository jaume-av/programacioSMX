paraules = []

for i in range(5):
    p = input("Introdueix una paraula: ")
    paraules.append(p)

mes_llarga = ""
comptador = 0

for p in paraules:
    if len(p) > len(mes_llarga):
        mes_llarga = p
    if len(p) > 5:
        comptador = comptador + 1

print("\nParaules:")
for p in paraules:
    print(p)

print("\nParaula més llarga:", mes_llarga)
print("Paraules amb més de 5 lletres:", comptador)
