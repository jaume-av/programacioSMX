inventari = {}

for i in range(5):
    producte = input("Producte: ")
    preu = float(input("Preu: "))
    inventari[producte] = preu

mes_barato = ""
preu_mes_barato = 0
mes_car = ""
preu_mes_car = 0

primer = True
total = 0

for producte in inventari:
    preu = inventari[producte]
    total = total + preu

    if primer == True:
        preu_mes_barato = preu
        preu_mes_car = preu
        mes_barato = producte
        mes_car = producte
        primer = False
    else:
        if preu < preu_mes_barato:
            preu_mes_barato = preu
            mes_barato = producte
        if preu > preu_mes_car:
            preu_mes_car = preu
            mes_car = producte

print("\nTotal:", total)
print("Producte més barat:", mes_barato, "-", preu_mes_barato)
print("Producte més car:", mes_car, "-", preu_mes_car)
