usuaris = {
    "laura": "1234",
    "joan": "abcd",
    "marta": "pass"
}

usuari = input("Usuari: ")

if usuari in usuaris:
    contrasenya = input("Contrasenya: ")
    if contrasenya == usuaris[usuari]:
        print("Accés correcte.")
    else:
        print("Contrasenya incorrecta.")
else:
    print("Usuari no existent.")
