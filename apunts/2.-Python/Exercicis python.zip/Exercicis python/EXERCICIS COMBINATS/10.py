alumnes = {}

opcio = 0

while opcio != 4:
    print("\nMENÚ")
    print("1. Afegir alumne")
    print("2. Mostrar alumnes")
    print("3. Mostrar aprovats")
    print("4. Eixir")

    opcio = int(input("Tria una opció: "))

    if opcio == 1:
        nom = input("Nom: ")
        nota = float(input("Nota: "))
        alumnes[nom] = nota

    elif opcio == 2:
        print("\nAlumnes:")
        for nom in alumnes:
            print(nom, "-", alumnes[nom])

    elif opcio == 3:
        print("\nAprovats:")
        for nom in alumnes:
            if alumnes[nom] >= 5:
                print(nom, "-", alumnes[nom])

    elif opcio == 4:
        print("Adeu!")

    else:
        print("Opció incorrecta.")
