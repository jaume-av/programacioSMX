secret = 7
intents = 5
encertat = False

while intents > 0 and encertat == False:
    num = int(input("Introdueix un número: "))

    if num == secret:
        encertat = True
    else:
        if num < secret:
            print("És més gran.")
        else:
            print("És més menut.")
        intents = intents - 1

if encertat == True:
    print("Has encertat!")
else:
    print("Has perdut. El número era", secret)
