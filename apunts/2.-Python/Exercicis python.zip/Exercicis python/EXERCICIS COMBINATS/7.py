numeros = []

for i in range(10):
    n = int(input("Introdueix un número: "))
    numeros.append(n)

suma = 0
comptador = 0

print("\nNúmeros parells:")
for n in numeros:
    if n % 2 == 0:
        print(n)
        suma = suma + n
        comptador = comptador + 1

print("\nSuma de parells:", suma)
print("Quantitat de parells:", comptador)
