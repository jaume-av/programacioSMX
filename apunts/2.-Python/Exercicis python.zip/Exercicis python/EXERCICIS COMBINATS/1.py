alumnes = {}

quantitat = int(input("Quants alumnes hi ha? "))

for i in range(quantitat):
    nom = input("Nom de l'alumne: ")
    nota = float(input("Nota: "))
    alumnes[nom] = nota

print("\nLlistat d'alumnes i notes:")
for nom in alumnes:
    print(nom, "-", alumnes[nom])

aprovats = 0
suma = 0

for nom in alumnes:
    suma = suma + alumnes[nom]
    if alumnes[nom] >= 5:
        aprovats = aprovats + 1

mitjana = suma / quantitat

print("\nAprovats:", aprovats)
print("Mitjana:", mitjana)
