numero = int(input("Introdueix un número: "))
i = 1

while i <= 10:
    print(numero, "x", i, "=", numero * i)
    i = i + 1
