num = 1
suma = 0

while num <= 10:
    suma = suma + num
    num = num + 1

print("La suma és:", suma)
