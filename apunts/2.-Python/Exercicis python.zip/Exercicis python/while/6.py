contador = 0
num = int(input("Introdueix un número (0 per acabar): "))

while num != 0:
    contador = contador + 1
    num = int(input("Introdueix un número (0 per acabar): "))

print("Has introduït", contador, "números")
