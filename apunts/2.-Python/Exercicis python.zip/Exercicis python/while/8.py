intents = 0
contrasenya = ""

while intents < 3 and contrasenya != "python123":
    contrasenya = input("Introdueix la contrasenya: ")
    intents = intents + 1

if contrasenya == "python123":
    print("Accés concedit")
else:
    print("Accés bloquejat")
