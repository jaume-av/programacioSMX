suma = 0
contador = 0
nota = float(input("Introdueix una nota (-1 per acabar): "))

while nota != -1:
    suma = suma + nota
    contador = contador + 1
    nota = float(input("Introdueix una nota (-1 per acabar): "))

if contador > 0:
    mitjana = suma / contador
    print("La mitjana és:", mitjana)
else:
    print("No s'ha introduït cap nota")
