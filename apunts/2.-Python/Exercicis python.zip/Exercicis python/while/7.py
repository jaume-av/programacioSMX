suma = 0
num = int(input("Introdueix un número (negatiu per acabar): "))

while num >= 0:
    suma = suma + num
    num = int(input("Introdueix un número (negatiu per acabar): "))

print("La suma total és:", suma)
