num = int(input("Introdueix un número positiu: "))

while num <= 0:
    num = int(input("Error. Introdueix un número positiu: "))

print("Número correcte:", num)
