suma = 0
contador = 0

for i in range(10):
    nota = float(input("Introdueix una nota (-1 per acabar): "))

    if nota == -1:
        break

    suma = suma + nota
    contador = contador + 1

if contador > 0:
    mitjana = suma / contador
    print("Mitjana:", mitjana)
else:
    print("No s'ha introduït cap nota vàlida")
