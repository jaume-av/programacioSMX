for intent in range(5):
    num = int(input("Introdueix un número positiu: "))

    if num > 0:
        print("Número correcte:", num)
        break
else:
    print("S'han esgotat els intents")
