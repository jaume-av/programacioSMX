suma = 0

for i in range(10):
    num = int(input("Introdueix un número: "))

    if num < 0:
        break

    suma = suma + num

print("Suma total:", suma)
