comptador = 0

for i in range(10):
    num = int(input("Introdueix un número: "))

    if num != 0:
        comptador = comptador + 1

print("Números diferents de 0:", comptador)
