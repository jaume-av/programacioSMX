for intent in range(3):
    password = input("Introdueix la contrasenya: ")

    if password == "python123":
        print("Accés concedit")
        break
else:
    print("Accés bloquejat")
