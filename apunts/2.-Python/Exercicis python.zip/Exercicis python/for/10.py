for i in range(1000):
    print("1. Saludar")
    print("2. Mostrar un número")
    print("3. Eixir")

    opcio = int(input("Tria una opció: "))

    if opcio == 1:
        print("Hola!")
    elif opcio == 2:
        num = int(input("Introdueix un número: "))
        print("Has escrit:", num)
    elif opcio == 3:
        print("Fins prompte!")
        break
    else:
        print("Opció no vàlida")
