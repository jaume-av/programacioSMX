for i in range(1000):  # simulació de bucle indefinit
    print("MENÚ")
    print("1. Comptar de l’1 al N")
    print("2. Sumar de l’1 al N")
    print("3. Mostrar parells fins a N")
    print("0. Eixir")

    opcio = int(input("Tria una opció: "))

    if opcio == 0:
        print("Programa finalitzat")
        break

    elif opcio == 1:
        n = int(input("Introdueix un número positiu: "))

        if n <= 0:
            print("Error: el número ha de ser positiu")
        else:
            for j in range(1, n + 1):
                print(j)

    elif opcio == 2:
        n = int(input("Introdueix un número positiu: "))

        if n <= 0:
            print("Error: el número ha de ser positiu")
        else:
            suma = 0
            for j in range(1, n + 1):
                suma = suma + j
            print("La suma és:", suma)

    elif opcio == 3:
        n = int(input("Introdueix un número positiu: "))

        if n <= 0:
            print("Error: el número ha de ser positiu")
        else:
            for j in range(0, n + 1, 2):
                print(j)

    else:
        print("Opció no vàlida")
