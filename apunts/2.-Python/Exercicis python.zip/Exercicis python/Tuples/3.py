numeros = (5, 12, 7, 20, 3, 15, 8)

print("Nombre d'elements:", len(numeros))

suma = 0
majors_10 = 0

for num in numeros:
    suma = suma + num
    
    if num > 10:
        majors_10 = majors_10 + 1

print("Suma total:", suma)
print("Majors que 10:", majors_10)
