numeros = (8, 16, 24, 32)

print("Segon element:", numeros[1])
print("Penúltim element:", numeros[len(numeros) - 2])
