dimensions = (4, 5, 3)

amplada, altura, profunditat = dimensions

producte = amplada * altura * profunditat

print("Amplada:", amplada)
print("Altura:", altura)
print("Profunditat:", profunditat)
print("Producte:", producte)
