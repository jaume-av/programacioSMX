llista = []

for i in range(5):
    num = int(input("Introdueix un número: "))
    llista.append(num)

t = tuple(llista)

print("Tuple final:", t)

major = t[0]
menor = t[0]
parells = 0

for num in t:
    
    if num > major:
        major = num
        
    if num < menor:
        menor = num
        
    if num % 2 == 0:
        parells = parells + 1

print("Número més gran:", major)
print("Número més menut:", menor)
print("Números parells:", parells)
