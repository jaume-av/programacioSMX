mesos = ("juny", "juliol", "agost")

for mes in mesos:
    print(mes)
