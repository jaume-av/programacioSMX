numeros = [4, 8, 15, 16, 23, 42]
buscar = int(input("Introdueix un número: "))

trobat = False

for num in numeros:
    if num == buscar:
        trobat = True
        break

if trobat == True:
    print("El número està dins de la llista")
else:
    print("El número no està dins de la llista")
