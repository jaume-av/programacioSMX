numeros = [5, 0, 3, 0, 8]

print("Elements:", len(numeros))
