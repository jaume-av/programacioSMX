numeros = [3, 6, 9, 12]

for num in numeros:
    print(num)
