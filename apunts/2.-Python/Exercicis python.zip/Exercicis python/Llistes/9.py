notes = [6, 8, 5, 9, 7]
suma = 0

for nota in notes:
    suma = suma + nota

mitjana = suma / len(notes)

print("Mitjana:", mitjana)
