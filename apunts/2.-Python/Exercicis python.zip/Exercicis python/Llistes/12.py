numeros = []

for i in range(10):
    num = int(input("Introdueix un número: "))
    numeros.append(num)

positius = 0
negatius = 0
zeros = 0

for num in numeros:
    if num > 0:
        positius = positius + 1
    elif num < 0:
        negatius = negatius + 1
    else:
        zeros = zeros + 1

print("Positius:", positius)
print("Negatius:", negatius)
print("Zeros:", zeros)
