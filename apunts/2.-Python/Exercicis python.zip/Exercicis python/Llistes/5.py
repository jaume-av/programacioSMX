numeros = []

for i in range(5):
    num = int(input("Introdueix un número: "))
    numeros.append(num)

print(numeros)
