n = int(input("Introdueix un número: "))

taula = []

for i in range(1, 11):
    taula.append(n * i)

print(taula)
