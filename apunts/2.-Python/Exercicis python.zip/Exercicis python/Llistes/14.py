# Versió 1


numeros = [1, 2, 3, 4, 5]

for i in range(len(numeros)-1, -1, -1):
    print(numeros[i]);





# Versió 2

"""
numeros = [1, 2, 3, 4, 5]
i = len(numeros) - 1

while i >= 0:
    print(numeros[i])
    i = i - 1
"""