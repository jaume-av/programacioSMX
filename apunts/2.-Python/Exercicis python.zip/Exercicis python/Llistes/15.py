notes = []

for i in range(5):
    nota = float(input("Introdueix una nota: "))
    notes.append(nota)

print("Notes:", notes)

major = notes[0]
menor = notes[0]
suma = 0

for nota in notes:
    suma = suma + nota

    if nota > major:
        major = nota

    if nota < menor:
        menor = nota

mitjana = suma / len(notes)

print("Nota més alta:", major)
print("Nota més baixa:", menor)
print("Mitjana:", mitjana)
