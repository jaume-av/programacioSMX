numeros = []

num = int(input("Introdueix un número (-1 per acabar): "))

while num != -1:
    numeros.append(num)
    num = int(input("Introdueix un número (-1 per acabar): "))

print(numeros)
