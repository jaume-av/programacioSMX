numeros = [2, 0, 4, 0, 0, 7]
contador = 0

for num in numeros:
    if num == 0:
        contador = contador + 1

print("Zeros:", contador)
