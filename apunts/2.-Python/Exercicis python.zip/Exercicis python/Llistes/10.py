numeros = [1, 4, 7, 8, 10, 3]

parells = []
senars = []

for num in numeros:
    if num % 2 == 0:
        parells.append(num)
    else:
        senars.append(num)

print("Parells:", parells)
print("Senars:", senars)
