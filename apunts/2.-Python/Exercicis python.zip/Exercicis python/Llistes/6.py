numeros = [-2, 5, 0, 3, -1, 4]
positius = 0

for num in numeros:
    if num > 0:
        positius = positius + 1

print("Positius:", positius)
