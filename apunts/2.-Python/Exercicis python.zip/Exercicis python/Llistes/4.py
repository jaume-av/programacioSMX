numeros = [1, 4, 6, 3]
suma = 0

for num in numeros:
    suma = suma + num

print("Suma:", suma)
