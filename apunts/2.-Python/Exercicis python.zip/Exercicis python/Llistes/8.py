numeros = [7, 2, 9, 4, 1]

major = numeros[0]

for num in numeros:
    if num > major:
        major = num

print("Major:", major)
