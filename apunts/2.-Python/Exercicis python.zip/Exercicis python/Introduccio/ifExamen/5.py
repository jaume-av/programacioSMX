a = float(input("Primer número: "))
b = float(input("Segon número: "))
opcio = int(input("Opció (1-sumar, 2-restar, 3-multiplicar, 4-dividir): "))

if opcio == 1:
    print("Resultat:", a + b)
elif opcio == 2:
    print("Resultat:", a - b)
elif opcio == 3:
    print("Resultat:", a * b)
elif opcio == 4:
    if b != 0:
        print("Resultat:", a / b)
    else:
        print("Error: divisió per zero")
else:
    print("Opció no vàlida")
