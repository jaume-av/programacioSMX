a = int(input("Primer número: "))
b = int(input("Segon número: "))
c = int(input("Tercer número: "))

if a >= b and a >= c:
    print("El major és", a)
elif b >= a and b >= c:
    print("El major és", b)
else:
    print("El major és", c)
