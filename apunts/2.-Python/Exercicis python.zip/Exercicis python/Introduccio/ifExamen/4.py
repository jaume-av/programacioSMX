nota = float(input("Introdueix una nota: "))

if nota >= 0 and nota <= 10:
    print("Nota correcta")
else:
    print("Nota incorrecta")
