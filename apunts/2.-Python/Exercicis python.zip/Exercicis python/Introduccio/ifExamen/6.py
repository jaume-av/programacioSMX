edat = int(input("Introdueix l'edat: "))
vip = input("Eres VIP? (True o False): ")

if edat < 18:
    print("Accés denegat")
else:
    if vip == "True":
        print("Accés premium")
    else:
        print("Accés normal")
