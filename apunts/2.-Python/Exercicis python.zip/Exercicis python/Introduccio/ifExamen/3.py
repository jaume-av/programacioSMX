import_total = float(input("Import de la compra: "))

if import_total < 100:
    preu_final = import_total
elif import_total <= 200:
    preu_final = import_total * 0.9
else:
    preu_final = import_total * 0.8

print("Preu final:", preu_final)
