temp = float(input("Introdueix la temperatura: "))

if temp < 0:
    print("Gel")
elif temp <= 15:
    print("Fred")
elif temp <= 25:
    print("Temperatura suau")
else:
    print("Calor")
