num = int(input("Introdueix un número: "))

if num % 2 == 0:
    print("El número és parell")
else:
    print("El número és imparell")
