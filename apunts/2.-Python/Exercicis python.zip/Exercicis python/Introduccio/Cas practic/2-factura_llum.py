consum = float(input("Consum mensual (kWh): "))
potencia = float(input("Potència contractada (kW): "))
bo_social = input("Tens bo social? (si o no): ")
nocturna = input("Tens tarifa nocturna? (si o no): ")

# 1) Validacions
if consum < 0 or potencia <= 0:
    print("Dades no vàlides")
else:
    # 2) Preu per kWh (simplificat: un sol tram per a tot el consum)
    if consum <= 100:
        preu_kwh = 0.15
    elif consum <= 250:
        preu_kwh = 0.20
    else:
        preu_kwh = 0.25

    cost_consum = consum * preu_kwh
    cost_potencia = potencia * 4.00
    total = cost_consum + cost_potencia

    # 3) Ajustos
    if nocturna == "si" and consum <= 200:
        total = total * 0.95
        info_nocturn = "Sí (5%)"
    else:
        info_nocturn = "No"

    if bo_social == "si":
        total = total * 0.75
        info_bo = "Sí (25%)"
    else:
        info_bo = "No"

    print("Preu kWh aplicat:", preu_kwh)
    print("Cost consum:", cost_consum)
    print("Cost potència:", cost_potencia)
    print("Descompte nocturn:", info_nocturn)
    print("Bo social:", info_bo)
    print("Total final:", total)
