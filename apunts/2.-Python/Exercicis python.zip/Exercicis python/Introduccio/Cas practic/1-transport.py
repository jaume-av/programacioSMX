trajecte = input("Trajecte (urbà o interurbà): ")
edat = int(input("Edat: "))
carnet_jove = input("Tens carnet jove? (si o no): ")
discapacitat = input("Tens discapacitat reconeguda? (si o no): ")

# 1) Validació del trajecte i preu base
if trajecte != "urbà" and trajecte != "interurbà":
    print("Trajecte no vàlid")
else:
    if trajecte == "urbà":
        preu_base = 1.50
    else:
        preu_base = 3.00

    # 2) Càlcul segons prioritats
    if discapacitat == "si":
        preu_final = preu_base * 0.5
        info = "Descompte del 50% per discapacitat"
    else:
        if edat < 12:
            preu_final = 0.0
            info = "Trajecte gratuït (menor de 12)"
        elif edat >= 12 and edat <= 25 and carnet_jove == "si":
            preu_final = preu_base * 0.7
            info = "Descompte del 30% per carnet jove"
        elif edat >= 65:
            preu_final = preu_base * 0.6
            info = "Descompte del 40% per a majors de 65"
        else:
            preu_final = preu_base
            info = "Sense descompte"

    print("Trajecte:", trajecte)
    print("Preu base:", preu_base)
    print(info)
    print("Preu final:", preu_final)
