numero = int(input("Introdueix un número enter: "))

if numero == 0:
    print("El número és zero")
else:
    print("El número no és zero")
