edat = int(input("Introdueix la teua edat: "))

if edat >= 18:
    print("Ets major d'edat")
else:
    print("Ets menor d'edat")
