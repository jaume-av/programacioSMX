nota = float(input("Introdueix la nota: "))

if nota >= 9:
    print("Excel·lent")
elif nota >= 5:
    print("Aprovat")
else:
    print("Suspés")
