edat = int(input("Introdueix la teua edat: "))

if edat < 18:
    print("Menor d'edat")
elif edat < 65:
    print("Adult")
else:
    print("Jubilat")
