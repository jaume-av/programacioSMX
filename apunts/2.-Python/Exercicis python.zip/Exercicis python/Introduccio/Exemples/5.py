edat = int(input("Introdueix la teua edat: "))
soci = input("Eres soci? (True o False): ")

if edat < 18:
    print("Accés denegat")
else:
    if soci == "True":
        print("Entrada amb descompte")
    else:
        print("Entrada normal")
