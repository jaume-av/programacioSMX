jugadors = {
    "Pere": 15,
    "Joan": 22,
    "Marc": 18,
    "David": 25,
    "Arnau": 20
}

major_punts = 0
millor_jugador = ""

for jugador in jugadors:
    if jugadors[jugador] > major_punts:
        major_punts = jugadors[jugador]
        millor_jugador = jugador

print("Jugador amb més punts:", millor_jugador)
print("Punts:", major_punts)