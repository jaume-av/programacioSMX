diners = {
    "Gener": 1000,
    "Febrer": 1200,
    "Març": 900,
    "Abril": 1100
}

total = 0

for mes in diners:
    total = total + diners[mes]

print("Total guanyat:", total)