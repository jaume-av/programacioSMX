notes = {
    "Matemàtiques": 7,
    "Valencià": 8,
    "Anglés": 6,
    "Història": 9,
    "Biologia": 5
}

print("Nombre d'assignatures:", len(notes))

print("Assignatures:")
for assignatura in notes:
    print(assignatura)