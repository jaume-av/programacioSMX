cotxe = {
    "marca": "Toyota",
    "model": "Corolla",
    "any": 2020
}

print("Model:", cotxe["model"])
print("Any:", cotxe["any"])