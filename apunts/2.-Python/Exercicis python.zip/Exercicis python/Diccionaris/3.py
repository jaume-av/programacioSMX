llibre = {}

titol = input("Introdueix el títol del llibre: ")
preu = float(input("Introdueix el preu del llibre: "))

llibre["titol"] = titol
llibre["preu"] = preu

print(llibre)