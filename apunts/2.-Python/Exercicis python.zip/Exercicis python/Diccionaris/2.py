persona = {
    "nom": "Laura",
    "edat": 18
}

persona["edat"] = 19

print(persona)