compra = {}

for i in range(3):
    producte = input("Introdueix el nom del producte: ")
    preu = float(input("Introdueix el preu: "))
    compra[producte] = preu

print("\nProductes comprats:")
for producte in compra:
    print(producte, "-", compra[producte])

total = 0
mes_car = ""
preu_mes_car = 0

for producte in compra:
    total = total + compra[producte]
    
    if compra[producte] > preu_mes_car:
        preu_mes_car = compra[producte]
        mes_car = producte

print("\nTotal de la compra:", total)
print("Producte més car:", mes_car, "-", preu_mes_car)