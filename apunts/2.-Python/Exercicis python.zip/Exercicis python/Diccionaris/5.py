productes = {
    "Pa": 1.2,
    "Llet": 0.9,
    "Arròs": 2.5,
    "Ous": 3.0
}

for producte in productes:
    print("Producte:", producte, "- Preu:", productes[producte])