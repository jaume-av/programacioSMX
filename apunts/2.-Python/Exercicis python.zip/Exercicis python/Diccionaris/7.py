capitals = {
    "Espanya": "Madrid",
    "França": "París",
    "Itàlia": "Roma",
    "Alemanya": "Berlín"
}

pais = input("Introdueix un país: ")

if pais in capitals:
    print("Capital:", capitals[pais])
else:
    print("El país no existeix en el diccionari.")