alumnes = {
    "Anna": 7,
    "Joan": 4,
    "Marta": 6,
    "Pau": 3,
    "Laura": 8,
    "Marc": 5
}

comptador = 0

for alumne in alumnes:
    if alumnes[alumne] >= 5:
        comptador = comptador + 1

print("Alumnes aprovats:", comptador)